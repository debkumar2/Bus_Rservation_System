<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="icon" href="./image/bus (1).png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Courgette&family=Nunito:ital,wght@0,300;0,400;0,600;1,300;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./style.css">
    <title>Travel's.Com</title>
</head>

<body>

    <!-- Navbar Starts  -->

    <div class="banner" id="home">
        <div class="nav-menu">
            <h1 class="logo">Travel's.Com</h1>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#Source-Desti">Destination</a></li>
                <li><a href="#service">Services</a></li>
                <li><a href="#about-us">About Us</a></li>
                <li><a href="#contact-us">Contact Us</a></li>
            </ul>
            <a href="login.php" class="login">Login</a>
        </div>

        <!-- Nabvar Ends -->

        <!-- Destination Input Starts -->
        <form action="availablebus.php" method="post">
            <div class="menu">
                <input type="text" name="" class="box" placeholder="From *">
                <input type="text" name="" class="box" placeholder="To *">
                <input type="number" name="" class="box" placeholder="No. of Passenger">
                <input type="date" name="date" class="box1" id="date">
                <button type="submit" class="btn-submit">Search</button>
            </div>
        </form>
    </div>

    <!-- Destination Input Ends -->

    <!-- Destination Card -->
    <div class="destination-main" id="Source-Desti">
        <div class="destination container">
            <h1 class="destination-head">Destination</h1>
            <div class="card">
                <div class="image">
                    <img src="./image/Calcutta.jpg" alt="">
                </div>
                <div class="title">
                    <h1 class="title-head">Kolkata</h1>
                </div>
                <div class="des">
                    <p class="des.para">
                        Kolkata, Bengali Kalikata, formerly Calcutta, city, capital of West Bengal state, and former
                        capital (1772–1911) of British India. It is one of India’s largest cities and one of its major
                        ports. The city is centred on the east bank of the Hugli (Hooghly) River</p>
                    <button class="visit">Visit<i class="fas fa-arrow-right"></i></button>
                </div>
            </div>
            <div class="card">
                <div class="image1">
                    <img src="./image/delhi.jpg" alt="Delhi">
                </div>
                <div class="title">
                    <h1 class="title-head">Delhi</h1>
                </div>
                <div class="des">
                    <p class="des.para">Delhi, city and national capital territory, north-central India. The city of
                        Delhi actually consists of two components: Old Delhi, in the north, the historic city; and New
                        Delhi, in the south, since 1947 the capital of India, built in the first part of the 20th
                        century </p>
                    <button class="visit">Visit<i class="fas fa-arrow-right"></i></button>
                </div>
            </div>
            <div class="card">
                <div class="image2">
                    <img src="./image/mumbai.jpg" alt="mumbai">
                </div>
                <div class="title">
                    <h1 class="title-head">Mumbai</h1>
                </div>
                <div class="des">
                    <p class="despara">Mumbai, formerly Bombay, city, capital of Maharashtra state, southwestern India.
                        It is the country’s financial and commercial centre and its principal port on the Arabian Sea,
                        Mumbai is India’s most-populous city, and it is one of the largest </p>
                    <button class="visit">Visit<i class="fas fa-arrow-right"></i></button>
                </div>
            </div>
        </div>
    </div>

    <!-- Destination Card Ends -->

    <!-- Services Area Starts -->

    <div class="services-area" id="service">
        <div class="container">
            <h2>Services</h2>
            <div class="row">
                <div class="col-6 col-md-4 services-item">
                    <i class="fas fa-piggy-bank icons">
                        <h3>Fixed Rate</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore
                        magna.
                    </p>
                    <i class="fas fa-heart icons">
                        <h3>Free Cancellation</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore
                        magna.
                    </p>
                    <i class="fas fa-lock icons">
                        <h3>Reliable transfers</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore
                        magna.
                    </p>
                </div>
                <div class="col-6 col-md-4 services-item">
                    <i class="fas fa-wallet icons">
                        <h3>No Booking Fees</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore
                        magna.
                    </p>
                    <i class="fas fa-magic icons">
                        <h3>Booking Flexibility</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore
                        magna.
                    </p>
                    <i class="fas fa-trophy icons">
                        <h3>Award Winning Service</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore
                        magna.
                    </p>
                </div>
                <div class="col-6 col-md-4 services-item">
                    <i class="fas fa-phone-alt icons">
                        <h3>24*7h Customer Service</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore
                        magna.
                    </p>
                    <i class="fas fa-hand-sparkles icons">
                        <h3>Quality Vehicles </h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore
                        magna.
                    </p>
                    <i class="fas fa-paperclip icons">
                        <h3>Benefits For Partners</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore
                        magna.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Services Area Ends -->

    <!-- About Section Starts -->

    <section class="main-about" id="about-us">
        <div class="container ">
            <div class="row about-section">
                <div class="col-6 about">
                    <h1 class="about-heading">About Us</h1>
                    <p class="about-title">Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident sint
                        itaque laborum, consequatur aspernatur impedit quae odio, cum, sapiente enim minima quod magnam
                        animi officia vitae autem ullam. Possimus, sapiente neque? Commodi adipisci quo deserunt quis
                        libero ut aut. Sed impedit minima eum consequuntur nemo perferendis libero? Quia, rerum
                        doloresLorem ipsum, dolor sit amet consectetur adipisicing elit. Numquam adipisci et esse,
                        dolores obcaecati blanditiis cumque alias doloremque at nobis delectus explicabo cum, impedit
                        consequuntur dicta facilis? Ab excepturi architecto asperiores, aliquam vel </p>
                </div>
                <div class="col-6 about-img">
                    <img src="./image/wp2120.jpg" alt="">
                </div>
            </div>
        </div>
    </section>

    <!-- About Section Ends -->

    <!-- Start Contact US Section -->
    <div class="main-contact" id="contact-us">
        <div class="container contact-con">
            <div class="row contact-row">
                <div class="col-6 contact-left">
                    <h2 class="add"><i class="fas fa-map-marker-alt"></i>21 Revolution Street</h2>
                    <p class="addpara">Paris, France</p>
                    <h2 class="phone"><i class="fas fa-phone-alt"></i>+91 154722328</h2>
                    <h2 class="mail"><i class="fas fa-envelope"></i>support@travel's.com</h2>
                </div>
                <div class="col-6 contact-left">
                    <h1 class="contact-com">About the Company</h1>
                    <p class="contact-info">Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem
                        nihil voluptatum, dolorem
                        quod dolorum deserunt dolore officiis sapiente iste possimus sint nam distinctio vitae magni.
                        Debitis, optio? Incidunt, pariatur quis.</p>
                    <div class="social-logo">
                        <i class="fab fa-facebook-f"></i>
                        <i class="fab fa-twitter"></i>
                        <i class="fab fa-instagram"></i>

                    </div>
                </div>
            </div>
            <div class="copyright">
                <p>©2021|All Rights Reserved</p>
                <p>|powered by<a href="#home">Travel's.com</a></p>
            </div>
        </div>

    </div>

    <!-- End Contact US Section -->


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>