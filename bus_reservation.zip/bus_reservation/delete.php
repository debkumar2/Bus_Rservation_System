<?php
error_reporting(0);
include "connection.php";
$id=$_REQUEST['id'];
$query="DELETE FROM customer WHERE id='$id'";
$data=mysqli_query($conn,$query);
if($data){
    echo '<script>alert("RECORD DELETED SUCCESSFULLY")</script>';
    echo '<script>window.location.href="/reservation/adminfetch.php"</script>';
}
?>