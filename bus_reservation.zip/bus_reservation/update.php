<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="./image/bus (1).png">
    <title>Update</title>
</head>

<body>
    <form action="" method="post">
        Firstname: <input type="text" value="<?php echo $_GET['firstname']; ?>" name="firstname">
        Lastname: <input type="text" value="<?php echo $_GET['lastname']; ?>" name="lastname">
        Contact:<input type="text" value="<?php echo $_GET['contact']; ?>" name="contact">
        Route: <input type="text" value="<?php echo $_GET['route']; ?>" name="route">
        Passenger: <input type="text" value="<?php echo $_GET['passenger']; ?>" name="passenger">
        <input type="submit" name="submit" value="UPDATE">
    </form>    
</body>

</html>
<?php
$conn = mysqli_connect("localhost", "root", "", "reservation") or mysqli_connect_error();
$ids = $_GET['id'];
$_GET['firstname'];
$_GET['lastname'];
$_GET['contact'];
$_GET['route'];
$_GET['passenger'];

if (isset($_REQUEST['submit'])) {
    $firstname = $_REQUEST['firstname'];
    $lastname = $_REQUEST['lastname'];
    $contact = $_REQUEST['contact'];
    $route = $_REQUEST['route'];
    $passenger = $_REQUEST['passenger'];
    $query = "UPDATE customer set firstname='$firstname', lastname='$lastname' , contact='$contact', route='$route' , passenger='$passenger'  where id='$ids'";
    $data = mysqli_query($conn, $query);
    if ($data) {
        echo '<script>alert("RECORD UPDATED SUCCESSFULLY")</script>';
        echo '<script>window.location.href="/reservation/adminfetch.php"</script>';
    }
}

?>