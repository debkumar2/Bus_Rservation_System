
<?php

include "connection.php";
session_start();
$conn=mysqli_connect("localhost", "root", "" ,"bus_reservation") or mysqli_connect_error();
if(!$_SESSION["login_user"]){
header("location:adminlogin.php");
}  
  
?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   
	  
	  
	  
	  
	  
	  
	  <br><br><br><br><br><br><br>
	  
	  
	  <b><a href="businsert.php"> Insert New Bus Details</a><br><br>
	  <a href="allbus.php"> View All Buses</a><br><br>
	  <a href="allbookings.php"> View all bookings</a><br></b><br>
      <a class="botton" href='adminlogout.php'>Logout</a>
</body>
</html> -->

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    
    <title>Navbar</title>
    <style>
    .bg-dark {
    background-color: #d0d0d0 !important;
}
 .nav-item .nav-link{
    margin: 0 25px;
    font-weight: 600;
    font-size: 13px;
    text-transform: uppercase;
    color: black !important;
}
.navbar-brand{
    color: #000 !important;
    font-weight: 600;
    font-size: 34px;
}
.navbar-brand:hover{
    color: #000;
}
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
        <a class="navbar-brand" href="#">Travel's.Com</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="col-auto">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item ">
              <a class="nav-link" href="#">Home </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="businsert.php">Insert New Bus</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allbus.php"> View All Buses</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allbookings.php"> View all bookings</a>
            </li>
             <li class="nav-item">
                <a class="nav-link" href="adminlogout.php">Logout</a>
            </li>
          </ul>
        </div>
        </div>
    </div>
      </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
  </body>
</html>
