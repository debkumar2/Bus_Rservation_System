<?php
include "connection.php";
$firstname=$_REQUEST['firstname'];
$lastname=$_REQUEST['lastname'];
$contact=$_REQUEST['contact'];
$route=$_REQUEST['route'];
$passenger=$_REQUEST['passenger'];
if(isset($_POST['submit'])){
    $query="INSERT INTO `customer`(`id`, `firstname`, `lastname`, `contact`, `route`, `passenger`) VALUES ('','$firstname','$lastname','$contact','$route', '$passenger')";
    $res=mysqli_query($conn,$query);
        echo '<script>alert("NEW RECORD CREATED SUCCESSFULLY")</script>';
    }
    else
    {
        echo '<script>alert("SOMETHING WENT WRONG")</script>';
    }

?>