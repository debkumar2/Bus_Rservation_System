<?php 
if(isset($_POST["route"]) && isset($_POST["date"]))
{
	$route=$_POST["route"];
	$date=$_POST["date"];
}
else
{
	header("location:index.php");
}

?>

<html>
<head><title>Available Buses</title>
<style>
	table, th, td {
		text-align:center;
  border: 1px solid black;
}
table{
	border-collapse: collapse;
}
	</style></head>

<body>

<h1>Available Buses</h1>
<h3>Route :<?php echo $route; ?></h3>
<h3>Date :<?php echo $date; ?></h3>

<table style="width:100%">
  <tr>
    <th>Bus Name</th>
	<th> Depurture Time</th>
	<th> Available Seats</th>
	<th> Fare</th>
  </tr>
  
  <?php

  
		 include "connection.php";
		  $query="SELECT * from bus where route='".$route."' order by time;";	
			$data=mysqli_query($conn,$query);
			if(mysqli_num_rows($data))
			{
				while ($row=mysqli_fetch_array($data))
				{
					$subquery = "Select sum(passenger) as psg from `bookings` where bus_id='".$row['id']."' and date='".$date."';";
					$subresult = mysqli_query($conn, $subquery);
					$occupied_seat = mysqli_fetch_assoc($subresult)['psg'];
					$available_seat=$row['seats']-$occupied_seat;
					
			echo '<tr>';
			echo	'<td>'.$row['name'].'</td>';
			echo	'<td>'.date("g:iA", strtotime($row['time'])).'</td>';
			echo	'<td>'.$available_seat.'</td>';
			echo	'<td>'.$row['price'].'/-</td>';
			echo '</tr>';
		}
	}
  
  
  
  ?>
  
</table> 
   
<br><br>
<a href="login.php">Please Login for Booking</a><br><br>
<a href="register.php">If you are new please do Register first</a>

</body>

</html>