<?php
session_start();
if(isset($_SESSION['passnot'])){
	$err=$_SESSION['passnot'];
    unset($_SESSION['passnot']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="./image/bus (1).png">
    <title>Register</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">

<link
    href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,300;0,400;0,600;0,700;1,600&display=swap"
    rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
</head>

<body>
<div class="background">
        <img src="./image/3.jpg" alt="">
        <div class="login-form">
            <form action="registeraction.php" method="post">
                <h1>Register</h1>
				<p class="sign">Full name</p>
                <input type="text" name="fullname" id="" placeholder="Full name" required></br></br>
				
                <p class="sign">Username</p>
                <input type="text" name="username" id="" placeholder="Username" required></br></br>
                <p class="sign">Password</p>
                <input type="password" name="password" id="" placeholder="Password" required></br></br>
                <p class="sign">Confirm Password</p>
                <input type="password" 
                name="connpassword" placeholder="Comfirm Password" required></br>
				
				<?php if(isset($err)) echo '<p class="text-danger font-weight-bold">Password Not matched</p>'; ?>
				
				</br>
				
				<p class="sign">Contact Number</p>
                <input type="text" 
                name="contact" placeholder="Contact Number" required></br><br>
				
                <button type="submit" value="Register" name="register" class="btn btn-primary"> Register </button>
                <a class="link" href="login.php">Login</a>
               
            </form>
        </div>
    </div>
</body>

</html>