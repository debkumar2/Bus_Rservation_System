<?php
session_start();
include "connection.php";
$fullname=$_POST['fullname'];
$username=$_POST['username'];
$password=$_POST['password'];
$connpassword=$_POST['connpassword'];
$contact=$_POST['contact'];

if(isset($_POST['register']))

{
   if($password!==$connpassword)
   {
       $_SESSION['passnot']="PASSWORD DOES NOT MATCHED";
       header("location:register.php");
   }
	
   else
   {
       $sql="select * from users where username='".$username."'";
       $res=mysqli_query($conn,$sql);
	   
       if(mysqli_num_rows($res))
	   {
           echo '<script>alert("USERNAME ALREADY EXISTS")</script>';
           echo '<script>window.location.href="register.php"</script>';
       }
		else
		{
			$query="INSERT INTO `users`(`fullname`,`username`, `password`,`contact`) VALUES('".$fullname."','".$username."','".$password."','".$contact."')";
			$reg=mysqli_query($conn,$query);
		
			if($reg)
			{
				echo '<script>alert("NEW RECORD SUCESSFULLY CREATED")</script>';
				echo '<script>window.location.href="login.php"</script>';
			}
			else
			{
				echo '<script>alert("Registration not done !")</script>';
				echo '<script>window.location.href="register.php"</script>';
			}
   		}
 }
}
?>