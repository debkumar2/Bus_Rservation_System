<?php
include "connection.php";

if(isset($_GET["id"]))
{
	$id=$_GET["id"];
	$query="SELECT * from bus where id='".$id."';";
				
	$data=mysqli_query($conn,$query);
	
	if(mysqli_num_rows($data))
	{
		mysqli_query($conn,"delete from bus where id='".$id."';");
		echo '<script>alert("Delete SUCESSFUL !")</script>';
		echo '<script>window.location.href="admindashboard.php"</script>';
	}
	else
	{
		echo '<script>alert("Delete failed !")</script>';
		echo '<script>window.location.href="admindashboard.php"</script>';
	}
	
	
}
else
	{
		echo '<script>alert("Delete failed !")</script>';
		echo '<script>window.location.href="admindashboard.php"</script>';
	}
?>