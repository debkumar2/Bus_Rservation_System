<?php
$conn=mysqli_connect("localhost", "root", "", "bus_reservation") or mysqli_connect_error();
?>