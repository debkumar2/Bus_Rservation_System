<?php

include "connection.php";
session_start();
$conn=mysqli_connect("localhost", "root", "" ,"bus_reservation") or mysqli_connect_error();
if(!$_SESSION["login_user"]){
header("location:login.php");
}  
  
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="./image/bus (1).png">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="css/nav.css">
    <title>Document</title>
	

	<style>
	table, th, td {
		text-align:center;
  border: 1px solid black;
}
table{
	border-collapse: collapse;
}
.main-div{
	margin: 10px 10px 0 10px;
}
	</style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
        <a class="navbar-brand" href="#">Travel's.Com</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="col-auto">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item ">
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="">Dashboard</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
          </ul>
        </div>
        </div>
    </div>
      </nav>
<div class="main-div">
   <h3>Welcome <?php echo $_SESSION["login_user"]; ?> </h3>
   
   <form method="GET" action="busbooking.php">
   <p>Plan Your Journey </p>
   
   
	   <label>Choose Route :</label>
	   <select name="route" required> 
	   <option value="">Select Here</option>
	   <?php 
	   include "connection.php";
		  $query="SELECT distinct(route) from bus order by route;";	
			$data=mysqli_query($conn,$query);
			if(mysqli_num_rows($data))
			{
				while ($row=mysqli_fetch_array($data))
				{
					echo '<option value="'.$row['route'].'">'.$row['route'].'</option>';
				}
			}
		?>
	   </select>
	   
	   <input type="date" name="date" required />
	   
	   <button type="submit" > Search Buses </button>
	 
   
   </form>
   
   
   <br><br>
   <hr>
   
   <br>
   
   <h3>Your Bookings :</h3>
   
    <table style="width:100%">
  <tr>
    <th>ID</th>
    <th>Bus Name</th>
    <th>Route</th>
	<th> Departure Time</th>
	<th> Passengers</th>
	<th> Fare</th>
	<th> Date</th>
	<th> Cancel</th>
  </tr>
  </div>
  <?php

  
  $query="SELECT bk.id as id, bk.passenger as psg, bs.name as name, bs.time as time, bs.route as route, bs.price as fare, bk.date as date from bookings as bk inner join bus as bs on bk.bus_id=bs.id inner join users on bk.user_id=users.id where users.id ='".$_SESSION['user']."' order by date desc;";
				
	$data=mysqli_query($conn,$query);
	
	if(mysqli_num_rows($data))
	{
		while ($row=mysqli_fetch_array($data))
		{
			echo '<tr>';
			echo	'<td>'.$row['id'].'</td>';
			echo	'<td>'.$row['name'].'</td>';
			echo	'<td>'.$row['route'].'</td>';
			echo	'<td>'.date("g:iA", strtotime($row['time'])).'</td>';
			echo	'<td>'.$row['psg'].'</td>';
			echo	'<td>'.$row['psg']*$row['fare'].'/-</td>';
			echo	'<td>'.$row['date'].'</td>';
			echo	'<td> <a href="cancelbooking.php?id='.$row['id'].'"> Cancel </a></td>';
			echo '</tr>';
		}
	}
    
  
  
echo  "</table></br></br>"; 
   

?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>

</html>