<?php
//error_reporting(0);
session_start();
include "connection.php";
$ids=$_GET['id'];
$_GET['route'];
$_GET['seats'];
$_GET['bookseat'];
$_GET['price'];
if(isset($_POST['submit'])){
    $query="UPDATE route SET seats=(seats-bookseat) where id=$ids";
    $res=mysqli_query($conn,$query);
    if($res){
    echo '<script>alert("NEW RECORD CREATED SUCCESSFULLY")</script>';
    echo '<script>window.location.href="/reservation/ticket.php"</script>';
    }
else{
    echo '<script>alert("Something Went Wrong")</script>';
    echo '<script>window.location.href="/reservation/details.php"</script>';
}
    }
// $firstname=$_REQUEST['firstname'];
// $lastname=$_REQUEST['lastname'];
// $contact=$_REQUEST['contact'];
// $route=$_REQUEST['route'];
// $passenger=$_REQUEST['passenger'];
// if(isset($_POST['submit'])){
//     $query="INSERT INTO `customer`(`id`, `firstname`, `lastname`, `contact`, `route`, `passenger`) VALUES ('','$firstname','$lastname','$contact','$route', '$passenger')";
//     $res=mysqli_query($conn,$query);
//         echo '<script>alert("NEW RECORD CREATED SUCCESSFULLY")</script>';
//         echo '<script>window.location.href="/reservation/ticket.php"</script>';
//     }
//     else
//     {
//         echo '<script>alert("SOMETHING WENT WRONG")</script>';
//         echo '<script>window.location.href="/reservation/details.php"</script>';
//     }

?>