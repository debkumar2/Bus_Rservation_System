<?php

include "connection.php";
session_start();

if(isset($_GET['route']))
{
	$route=$_GET['route'];
}
else
{
	echo "route not found !";
}


if(isset($_GET['date']))
{
	$date=$_GET['date'];
}
else
{
	echo "date not found !";
}


if(isset($_POST['submit']))
{
	$bus=$_POST['bus'];
	$passenger=$_POST['passenger'];
	
	if($passenger<=$_POST["avl"])
	{
		$sub="select * from bookings where `user_id`='".$_SESSION['user']."' and `bus_id`='".$bus."' and `date`='".$date."';";
		$res=mysqli_query($conn,$sub);
		if(mysqli_num_rows($res))
		{
			echo '<script>alert("You have already booked !")</script>';
			echo '<script>window.location.href="dashboard.php"</script>';
		}
		
		else
		{
	
			$query="INSERT INTO `bookings` (`user_id`,`bus_id`,`passenger`,`date`) VALUES('".$_SESSION['user']."','".$bus."','".$passenger."','".$date."')";
			
			$book=mysqli_query($conn,$query);

			if($book)
			{
				echo '<script>alert("BOOKING SUCESSFUL !")</script>';
				echo '<script>window.location.href="dashboard.php"</script>';
			}
			else
			{
				echo '<script>alert("BOOKING FAILED !")</script>';
				echo '<script>window.location.href="dashboard.php"</script>';
			}
		}
}

else
{
	echo '<script>alert("Available seats are insufficient !")</script>';
}

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
   <h3>Welcome <?php echo $_SESSION["login_user"]; ?> </h3>
   
   <form method="POST" >
   <p>Complete Your Booking Now </p>
   
   
	   <h4>Route : <?php echo $route; ?></h4>
	   <h4>date : <?php echo $date; ?> </h4>
	   
	   
	   
	   <label>Chose your bus :</label>
	   <select id="bus" name="bus" required onchange="my_func(this.value)"> 
	   <option value="">Select Here</option>
	   <?php 
	   include "connection.php";
		  $query="SELECT * from bus where route='".$route."' order by time;";	
			$data=mysqli_query($conn,$query);
			if(mysqli_num_rows($data))
			{
				while ($row=mysqli_fetch_array($data))
				{
					$subquery = "Select sum(passenger) as psg from `bookings` where bus_id='".$row['id']."' and date='".$date."';";
					$subresult = mysqli_query($conn, $subquery);
					$occupied_seat = mysqli_fetch_assoc($subresult)['psg'];
					$available_seat=$row['seats']-$occupied_seat;
					
					//if($available_seat>0)
					//{
					echo '<option value="'.$row['id'].'"> Bus Name : '.$row['name'].' | Time: '.date("g:iA", strtotime($row['time'])).' | Available Seats : '.$available_seat.' | Fare :'.$row['price'].'/-</option>';
					
					echo '<input id="'.$row['id'].'" type="number" value="'.$available_seat.'" hidden  />';
					//}
				}
			}
		?>
	   </select>
	   <br><br>
	   
	   <input id="avl" type="number" name="avl" hidden />
	   
	   <label>Passengers : </label>
	   <input type="number" id="passenger" min=1 name="passenger" value="1" max="200" required>
	   <button type="submit" name="submit"> Book</button>
	 
   
   </form>
   
   
   <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
   
   
   <script>
   function my_func(val){
	   var available=$("#"+val).val();
	   $("#avl").val(available);
	   $("#passenger").attr('max',available);
   }
   
   </script>
   
   
</body>

</html>