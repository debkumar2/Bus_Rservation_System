<?php
error_reporting(0);
session_start();
if(isset($_SESSION["unsuccessfull"])){
echo $_SESSION["unsuccessfull"];
unset($_SESSION["unsuccessfull"]);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login Page</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">

<link
    href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,300;0,400;0,600;0,700;1,600&display=swap"
    rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <div class="background">
        <img src="./image/3.jpg" alt="">
        <div class="login-form">
    <form action="adminaction.php" method="post">
       <h1>Admin Login</h1>
       <p class="sign">Username</p>
       <input type="text" name="username" value="<?php if(isset($_COOKIE['username'])){ echo $_COOKIE['username'];} ?>" required></br></br>
        <p class="sign">Password</p>
        <input type="password" name="password" value="<?php if(isset($_COOKIE['password'])){ echo $_COOKIE['password'];} ?>" required></br></br>
        <label for="remember">Remember</label>
        <input type="checkbox" name="remember" <?php if(isset($_COOKIE['remember'])) { echo "checked";  } ?>> </br></br>
        <input type="submit" value="Login" name="submit" class="botton">
    </form>
    </div>
</div>
</body>
</html>
