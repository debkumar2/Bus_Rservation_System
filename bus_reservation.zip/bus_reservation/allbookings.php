<?php

include "connection.php";
session_start();
// $conn=mysqli_connect("localhost", "root", "" ,"reservation") or mysqli_connect_error();
// if(!$_SESSION["login_user"]){
// header("location:adminlogin.php");
// }
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    
    <title>All Booking</title>
    <style>
    .bg-dark {
    background-color: #d0d0d0 !important;
}
 .nav-item .nav-link{
    margin: 0 25px;
    font-weight: 600;
    font-size: 13px;
    text-transform: uppercase;
    color: black !important;
}
.navbar-brand{
    color: #000 !important;
    font-weight: 600;
    font-size: 34px;
}
.navbar-brand:hover{
    color: #000;
}
		table,
		th,
		td {
			text-align: center;
			border: 1px solid black;
		}

		table {
			border-collapse: collapse;
		}
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
        <a class="navbar-brand" href="#">Travel's.Com</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="col-auto">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item ">
              <a class="nav-link" href="admindashboard.php">Home </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="businsert.php">Insert New Bus</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allbus.php"> View All Buses</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allbookings.php"> View all bookings</a>
            </li>
             <li class="nav-item">
                <a class="nav-link" href="adminlogout.php">Logout</a>
            </li>
          </ul>
        </div>
        </div>
    </div>
      </nav>
	<h3>Welcome <?php echo $_SESSION["login_user"]; ?> </h3>





	<br>

	<h3>All Bookings :</h3>

	<table style="width:100%">
		<tr>
			<th>ID</th>
			<th>Bus Name</th>
			<th>Customer name</th>
			<th>Route</th>
			<th> Depurture Time</th>
			<th> Passengers</th>
			<th> Fare</th>
			<th> Date</th>
			<th> Cancel</th>
		</tr>

		<?php


		$query = "SELECT bk.id as id, bk.passenger as psg, users.fullname, bs.name as name, bs.time as time, bs.route as route, bs.price as fare, bk.date as date from bookings as bk inner join bus as bs on bk.bus_id=bs.id inner join users on bk.user_id=users.id  order by date desc;";

		$data = mysqli_query($conn, $query);

		if (mysqli_num_rows($data)) {
			while ($row = mysqli_fetch_array($data)) {
				echo '<tr>';
				echo	'<td>' . $row['id'] . '</td>';
				echo	'<td>' . $row['name'] . '</td>';
				echo	'<td>' . $row['fullname'] . '</td>';
				echo	'<td>' . $row['route'] . '</td>';
				echo	'<td>' . date("g:iA", strtotime($row['time'])) . '</td>';
				echo	'<td>' . $row['psg'] . '</td>';
				echo	'<td>' . $row['psg'] * $row['fare'] . '/-</td>';
				echo	'<td>' . $row['date'] . '</td>';
				echo	'<td> <a href="admincancelbooking.php?id=' . $row['id'] . '"> Cancel </a></td>';
				echo '</tr>';
			}
		}

		?>

	</table>



</body>

</html>