<?php
include "connection.php";

if(isset($_GET["id"]))
{
	$id=$_GET["id"];
	$query="SELECT * from bookings where id='".$id."';";

	$data=mysqli_query($conn,$query);

	if(mysqli_num_rows($data))
	{
		mysqli_query($conn,"delete from bookings where id='".$id."';");
		echo '<script>alert("Booking Cancelled !")</script>';
		echo '<script>window.location.href="admindashboard.php"</script>';
	}
	else
	{
		echo '<script>alert("Failed !")</script>';
		echo '<script>window.location.href="admindashboard.php"</script>';
	}


}
else
	{
		echo '<script>alert("Failed !")</script>';
		echo '<script>window.location.href="dashboard.php"</script>';
	}
?>