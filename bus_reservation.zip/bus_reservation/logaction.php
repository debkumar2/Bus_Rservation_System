<?php
    error_reporting(0);
    session_start();
    include "connection.php";
    $username = $_REQUEST['username'];
    $password =  $_REQUEST['password'];
    $remember = $_REQUEST['remember'];
    if (isset($_POST['submit'])) {
        if (isset($_POST['remember'])) {
            setcookie('username', $username, time() + 60 * 60 * 7);
            setcookie('password', $password, time() + 60 * 60 * 7);
            setcookie('remember', $remember, time() + 60 * 60 * 7);
        } else {
            setcookie('username', $username, time() - 60 * 60 * 7);
            setcookie('password', $password, time() - 60 * 60 * 7);
            setcookie('remember', $remember, time() - 60 * 60 * 7);
        }
        $query = "Select * from `users` where username='".$username."' and password='".$password."'";
        $result = mysqli_query($conn, $query);
        $found_num_rows = mysqli_num_rows($result);
		
        if ($found_num_rows) {
            $_SESSION["user"] = mysqli_fetch_assoc($result)['id'];
			$_SESSION["login_user"] = $username;
            header("location:dashboard.php");
        }
         else {
            $_SESSION["unsuccessfull"] = "INVALID USER DETAILS";
            header("location:login.php");
        }
    }

?>
  