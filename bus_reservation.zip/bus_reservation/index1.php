<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">

    <link
        href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,300;0,400;0,600;0,700;1,600&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Bus Reservation System</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg ">
        <a class="navbar-brand brand-logo" href="#">Travel's.Com</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="nav-menu" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Reservation</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="register.php">Register</a>
                </li>

            </ul>
            <ul>

        </div>
    </nav>
    <!-- <nav>
        <label class="logo">Travel's.Com</label>
        <ul>
            <li><a href="#">HOME</a></li>
            <li><a href="#">RESERVATION</a></li>
            <li><a href="#">LINES</a></li>
            <li><a href="#">ABOUT US</a></li>
            <li><a href="#">CONTACT US</a></li>
        </ul>
    </nav> -->
    <div class="banner">
        <img src="./image/bus-1256105600.jpg" alt="">
        <div class="overlay"> </div>
        <div class="banner-form">
            <h1>Plan Your Journey</h1>
            
            <form action="availablebus.php" method="post">
			<p>Route</p>
                <input type="text" list="place" class="option" name="route" placeholder="Route">
                <datalist id="place">					
					<?php
					  include "connection.php";
					  $query="SELECT distinct(route) from bus order by route;";			
						$data=mysqli_query($conn,$query);
						if(mysqli_num_rows($data))
						{
							while ($row=mysqli_fetch_array($data))
							{
								echo '<option>'.$row['route'].'</option>';
							}
						}
					?>
                    
					
					
                </datalist>
                
                <p>Date</p>
                <input type="date" name="date" value="<?php echo date('Y-m-d', time()); ?>" min="<?php echo date('Y-m-d', time()); ?>" id="date"></br>
                <button type="submit" class="button"  > Check Now</button>
            </form>
        </div>
    </div>
    <div class="container">
    <div class="about">
        <h2>ABOUT US</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus minima dolores nihil inventore
            reprehenderit vero totam quos optio impedit facere reiciendis, quis deserunt error officia ipsam magni
            dolor. Consequatur doloremque libero tempora adipisci consequuntur Lorem ipsum dolor sit amet consectetur
            adipisicing elit. Debitis, nostrum! Nisi reprehenderit amet placeat veritatis doloremque dolor vel ipsa,
            ratione, ut magni aliquid eius omnis, sequi sed deleniti exercitationem deserunt dicta? Distinctio?</p>
        <div class="row">
            <div class="col-4">
                <img src="./image/5510989.jpg" alt="">
            </div>
            <div class="col-8">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium fuga itaque totam fugiat rem
                    nihil aspernatur? Quisquam maiores beatae qui voluptatum, facere nostrum ducimus error eligendi
                    soluta laudantium nobis eius doloribus consectetur ratione repellendus omnis deleniti ab? Ratione
                    veniam rem cum ipsa at, nam vitae quas, deleniti neque ad temporibus, culpa iste nihil consequuntur
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat quaerat vero, sit ullam voluptate
                    aliquam?</p>
            </div>
        </div>
    </div>
    </div>
    <div class="services-area">
        <div class="container">
            <h2>Services</h2>
            <div class="row">
                <div class="col-6 col-md-4">
                    <i class="fas fa-piggy-bank icons">
                        <h3>Fixed Rate</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore magna.
                    </p>
                    <i class="fas fa-heart icons">
                        <h3>Free Cancellation</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore magna.
                    </p>
                    <i class="fas fa-lock icons">
                        <h3>Reliable transfers</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore magna.
                    </p>
                </div>
                <div class="col-6 col-md-4">
                    <i class="fas fa-wallet icons">
                        <h3>No Booking Fees</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore magna.
                    </p>
                    <i class="fas fa-magic icons">
                        <h3>Booking Flexibility</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore magna.
                    </p>
                    <i class="fas fa-trophy icons">
                        <h3>Award Winning Service</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore magna.
                    </p>
                </div>
                <div class="col-6 col-md-4">
                    <i class="fas fa-phone-alt icons">
                        <h3>24*7h Customer Service</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore magna.
                    </p>
                    <i class="fas fa-hand-sparkles icons">
                        <h3>Quality Vehicles </h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore magna.
                    </p>
                    <i class="fas fa-paperclip icons">
                        <h3>Benefits For Partners</h3>
                    </i>
                    <p class="para">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy tinc dolore magna.
                    </p>

                </div>
            </div>
        </div>
    </div>
    <div class="footer">
    <div class="container ">
        <h1>Conatct Us</h1>
        <div class="row">
            <div class="col-4">
                <i class="fas fa-map-marker-alt"></i>
                <h3>UNIQUE Infoway</h3>
                <p>104, Some street, NewYork, USA</p>
                <i class="fas fa-phone-alt phone"></i>
                <h3>Call Us</h3>
                <p>+17112242</p>
                <i class="far fa-envelope"></i>
                <h3>Email Us</h3>
                <p>support@travel's.com</p>
                <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
                <a href=""><i class="fab fa-twitter"></i></a>
                <a href=""><i class="fab fa-pinterest"></i></a>
                <a href=""><i class="fab fa-instagram"></i></a>
            </div>
            <div class="col-8 contact-form">
                <input type="text" name="" id="name" placeholder="Name"></br>
               <input type="email" name="email" id="email" placeholder="email"></br>
                <input type="text" name="message" id="message" placeholder="message"></br>
                <input type="button" class="btn btn-success" value="Send">
            </div>
        </div>
    </div>
</div>

</body>

</html>