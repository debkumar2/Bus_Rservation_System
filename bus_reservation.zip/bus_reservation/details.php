
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">

<link
    href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,300;0,400;0,600;0,700;1,600&display=swap"
    rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
</head>

<body>
<div class="background">
        <img src="./image/3.jpg" alt="">
        <div class="login-form">
            <form action="/reservation/datailsaction.php" method="post">
                <h1>Details</h1>
                <p class="sign">Firstname</p>
                <input type="text" name="firstname" id="" required></br></br>
                <p class="sign">Lastname</p>
                <input type="text" name="lastname" id="" required></br></br>
                <p class="sign">Contact-Number</p>
                <input type="number" name="contact" id="" required></br></br>
                <p class="sign">Route</p>
                <input type="text" list="place" class="option" name="route" placeholder="Route" required>
                <datalist id="place">
                    <option>Berhampore-kolkata</option>
                    <option>Kolkata-Berhampore</option>
                </datalist></br></br>
                <p class="sign">Passenger</p>
                <input type="number" name="passenger" id="" required></br></br>
                <input type="submit" value="Submit" name="submit" class="button">
                <a class="botton" href='/reservation/logout.php'>Logout</a>
            </form>
        </div>
    </div> 
</body>
</html>
<?php
session_start();
if(!$_SESSION["login_user"]){
header("location:/reservation/login.php/");
}

    // echo "welcome";
    // echo "<a href='/reservation/logout.php'>Logout</a>";

?>
