<?php
 
    include "connection.php";
	$query = "Select sum(passengers) as psg from `bookings` where busid='2' and date='2021-06-16';";
    $result = mysqli_query($conn, $query);
       
    echo $avl = mysqli_fetch_assoc($result)['psg'];
	
	?>