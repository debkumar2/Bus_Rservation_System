<?php
include "connection.php";
if(isset($_POST["submit"]))
{
	$name = $_POST['name'];
	$route = $_POST['route'];
	$seats = $_POST['seats'];
	$price = $_POST['price'];
	$time = $_POST['time'];

	   $sql="select * from bus where name='".$name."' and route= '".$route."'";
       $res=mysqli_query($conn,$sql);

       if(mysqli_num_rows($res))
	   {
           echo '<script>alert("Bus Details Already EXISTS")</script>';
       }
		else
		{
			$query="INSERT INTO `bus`(`name`,`route`,`seats`,`price`,`time`) VALUES('".$name."','".$route."','".$seats."','".$price."','".$time."')";
			$reg=mysqli_query($conn,$query);

			if($reg)
			{
				echo '<script>alert("NEW RECORD SUCESSFULLY CREATED")</script>';
				echo '<script>window.location.href="admindashboard.php"</script>';
			}
			else
			{
				echo '<script>alert("Registration not done !")</script>';
			}
   		}

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus insert</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">

<link
    href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,300;0,400;0,600;0,700;1,600&display=swap"
    rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <div class="background">
        <img src="./image/3.jpg" alt="">
        <div class="login-form">
    <form method="post">
       <h1>New Bus Entry</h1>

       <p class="sign">1. Bus Name</p>
       <input type="text" name="name" required></br></br>

	    <p class="sign">2. Route</p>
       <input type="text" name="route" required></br></br>

	   <p class="sign">3. Total Seats</p>
       <input type="number" name="seats" min=0  required></br></br>

	   <p class="sign">4. Price per seat</p>
       <input type="number" name="price" min=0 required></br></br>
	   
	    <p class="sign">5. Departure time</p>
       <input type="time" name="time" required></br></br>


        </br></br>
        <input type="submit" value="Submit" name="submit" class="botton">
    </form>
    </div>
</div>
</body>
</html>
