<?php

include "connection.php";
session_start();
$conn=mysqli_connect("localhost", "root", "" ,"bus_reservation") or mysqli_connect_error();
if(!$_SESSION["login_user"]){
header("location:adminlogin.php");
}  
  
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>All buses</title>
</head>
<body>
<style>
    .bg-dark {
    background-color: #d0d0d0 !important;
}
 .nav-item .nav-link{
    margin: 0 25px;
    font-weight: 600;
    font-size: 13px;
    text-transform: uppercase;
    color: black !important;
}
.navbar-brand{
    color: #000 !important;
    font-weight: 600;
    font-size: 34px;
}
.navbar-brand:hover{
    color: #000;
}
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
        <a class="navbar-brand" href="#">Travel's.Com</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="col-auto">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item ">
              <a class="nav-link" href="admindashboard.php">Home </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="businsert.php">Insert New Bus</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allbus.php"> View All Buses</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allbookings.php"> View all bookings</a>
            </li>
             <li class="nav-item">
                <a class="nav-link" href="adminlogout.php">Logout</a>
            </li>
          </ul>
        </div>
        </div>
    </div>
      </nav>
      <!-- <a class="botton" href='adminlogout.php'>Logout</a> -->

	  
	  <br><br><br>
	  
	  <h1 class="text-primary text-center">All buses</h1>

	  
	  <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Route</th>
      <th scope="col">Seats</th>
	  <th scope="col">Price</th>
	  <th scope="col">Time</th>
	  <th scope="col">Edit</th>
	  <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
  
  <?php
  include "connection.php";
  
  $query="SELECT * from bus order by name;";
				
	$data=mysqli_query($conn,$query);
	
	if(mysqli_num_rows($data))
	{
		$count=0;
		while ($row=mysqli_fetch_array($data))
		{
			$count++;
  echo '<tr><th scope="row">'.$count.'</th>';
  echo'<td>'.$row['name'].'</td>';
  echo'<td>'.$row['route'].'</td>';
  echo'<td>'.$row['seats'].'</td>';
  echo'<td>'.$row['price'].'</td>';
  echo'<td>'.date("g:iA", strtotime($row['time'])).'</td>';
  $l1="busedit.php?id=".$row['id'];
  $l2="busdelete.php?id=".$row['id'];
  echo'<td><a class="btn btn-primary" href="'.$l1.'">Edit</a></td>';
  echo'<td><a class="btn btn-danger" href="'.$l2.'">Delete</a></td></tr>';
		}
	}
	
    ?>
  </tbody>
</table>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	 
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>	  
</body>
</html>

